package com.rent.movie.service;

import com.rent.movie.pojo.Movie;

public interface MovieService {

    String add(Movie movie);

}
