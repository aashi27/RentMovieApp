package com.rent.movie.pojo;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class Movie {


    private String id;
    private String title;
    private Integer yearOfProd;
    private Genre genre;
    private Producer producer;
    private FilmStudio studio;
    private List<Actor> actors;

}
