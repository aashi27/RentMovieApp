package com.rent.movie.Config;

import org.springframework.boot.autoconfigure.web.WebProperties;
import org.springframework.context.annotation.Bean;

@org.springframework.context.annotation.Configuration
public class Configuration {

    @Bean
    public WebProperties.Resources resources() {
        return new WebProperties.Resources();
    }
}
