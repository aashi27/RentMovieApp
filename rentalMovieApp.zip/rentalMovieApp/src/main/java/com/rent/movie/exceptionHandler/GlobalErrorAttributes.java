package com.rent.movie.exceptionHandler;

import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.reactive.error.DefaultErrorAttributes;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;

import java.util.Map;

import static com.rent.movie.exceptionHandler.CanNotRentMovieException.ErrorCode.*;
import static org.springframework.http.HttpStatus.*;

@Component
public class GlobalErrorAttributes extends DefaultErrorAttributes {

    @Override
    public Map<String, Object> getErrorAttributes(ServerRequest request,
                                                  ErrorAttributeOptions options) {
        Map<String, Object> map = super.getErrorAttributes(
                request, options);
        CanNotRentMovieException error = (CanNotRentMovieException) getError(request);
        map.put("error", error.getErrorCode());
        map.put("status", BAD_REQUEST);

        map.put("message", error.getMessage());
        return map;
    }
}
