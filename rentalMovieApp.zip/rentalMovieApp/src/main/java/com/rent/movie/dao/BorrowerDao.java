package com.rent.movie.dao;

import com.rent.movie.pojo.Borrower;
import com.rent.movie.pojo.Movie;

import java.util.Date;


public interface BorrowerDao {

    void add(Borrower borrower);

    Borrower get(String borrowerId);

    void update(String borrowerId, String movieId, Date date);

}
