package com.rent.movie.service.impl;


import com.rent.movie.pojo.Movie;
import com.rent.movie.service.MovieService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class MovieServiceImpl implements MovieService {


    @Override
    public String add(Movie movie) {
        return null;
    }
}
