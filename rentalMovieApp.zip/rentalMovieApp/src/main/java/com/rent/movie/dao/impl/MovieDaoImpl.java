package com.rent.movie.dao.impl;

import com.rent.movie.dao.MovieDao;
import com.rent.movie.pojo.Movie;
import org.springframework.stereotype.Repository;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class MovieDaoImpl implements MovieDao {

    private final Map<String, Movie> movieMap = new ConcurrentHashMap<>();

    @Override
    public String add(Movie movie) {
        if (movieMap.containsKey(movie.getId()))
            return null;
        else
            movieMap.put(movie.getId(), movie);
        return movie.getId();
    }

    @Override
    public Movie get(String movieId) {
        return movieMap.get(movieId);
    }
}
