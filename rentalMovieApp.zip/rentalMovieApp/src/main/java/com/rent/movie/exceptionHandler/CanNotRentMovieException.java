package com.rent.movie.exceptionHandler;

import lombok.Getter;

public class CanNotRentMovieException extends RuntimeException {

    @Getter
    private final ErrorCode errorCode;

    @Getter
    private final Object details;

    public CanNotRentMovieException(ErrorCode errorCode, Object details, String message) {
        super(message);
        this.errorCode = errorCode;
        this.details = details;
    }

    public enum ErrorCode {
        MOVIE_IS_RENTED_TO_SOMEONE_ELSE,
        CAN_NOT_RENT_SAME_MOVIE_MORE_THEN_ONCE,
        MOVIE_IS_NOT_AVAILABLE,
        CAN_NOT_RENT_MORE_THEN_2_MOVIES_AT_A_TIME,

        BORROWER_NOT_FOUND_PLEASE_REGISTER_THE_BORROWER_FIRST,

        NOT_VALID_YEAR
    }
}
