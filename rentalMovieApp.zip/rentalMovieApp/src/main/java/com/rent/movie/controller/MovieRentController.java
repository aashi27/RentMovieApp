package com.rent.movie.controller;

import com.rent.movie.service.RentalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@Slf4j
@Validated
@RestController
@RequestMapping("/api/v1/movie")
public class MovieRentController {

    @Autowired
    private RentalService rentalService;



    @Operation(summary = "Rent a new movie from movie data base",
            description = "This stub implementation will return a movie id for successfully rented movie<br/>" +
                    "To simulate service errors, it will return an error if movie is not rented due to some error " +
                    "or already rented<br/>"
                   )
    @ApiResponses(value = {@ApiResponse(responseCode = "200",
            description = "Movie rented to borrower"),
            @ApiResponse(responseCode = "400",
                    description = "Movie already rented to someone else",
                    content = @Content),
            @ApiResponse(responseCode = "400",
                    description = "You can not borrow more then 2 movies",
                    content = @Content),
            @ApiResponse(responseCode = "500",
                    description = "Movie not rented due to an unexpected internal error",
                    content = @Content),
            @ApiResponse(responseCode = "503",
                    description = "Movie not rented due to a temporary internal error",
                    content = @Content)})
    @PostMapping
    @RequestMapping("/rent")
    public ResponseEntity<?> rentMovie(@NotNull @Valid @RequestBody RentRequest request) {
        log.info("Processing Addition {}]", request);
        String movieId = rentalService.rentMovie(request.getMovieId(),request.getBorrowerId());
        return ResponseEntity.ok().build();
    }

  
    @Operation(summary = "Get top 10 movies rented in the year",
            description =
                    "In this stub implementation all movie ids rented in given year<br/>" 
                            )
    @ApiResponses(value = {@ApiResponse(responseCode = "200",
            description = "Found product",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = RentResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid year supplied", content = @Content),
            @ApiResponse(responseCode = "404", description = "No Movie Rented in this year", content = @Content)})
    @GetMapping("/{year}")
    public RentResponse getTop10MoviesRentedInThisYear(@NotNull @PathVariable Integer year) {

        List<String> topRentedMoviesOfYear = rentalService.getTopRentedMoviesOfYear(year);
        return new RentResponse(topRentedMoviesOfYear,year);
    }
    @Data
    public static class RentRequest {
        @NotNull
        private String movieId;
        @NotNull
        private String borrowerId;
    }

    @Data
    public static class RentResponse {
        @NotNull
        private List<String> topRentedMoviesOfYear;
        @NotNull
        private Integer year;

        public RentResponse(List<String> topRentedMoviesOfYear, Integer year) {
        }
    }
}
