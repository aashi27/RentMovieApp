package com.rent.movie.dao.impl;

import com.rent.movie.dao.RentalDao;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class RentalDaoImpl implements RentalDao {

    private final Map<String, List<Date>> movieRentalMap = new ConcurrentHashMap<>();

    @Override
    public List<Date> getRentalInfoForMovie(String movieId) {
        if (movieRentalMap.containsKey(movieId))
            return movieRentalMap.get(movieId);
        return null;
    }


    @Override
    public void saveRentalInfo(Date date, String movieId) {
        if (movieRentalMap.containsKey(movieId))
            movieRentalMap.get(movieId).add(date);
        else {
            List<Date> dates = new ArrayList<>();
            dates.add(date);
            movieRentalMap.put(movieId,dates);
        }
    }

    @Override
    public Map<String, List<Date>> getRentalInfo() {
        return movieRentalMap;
    }
}
