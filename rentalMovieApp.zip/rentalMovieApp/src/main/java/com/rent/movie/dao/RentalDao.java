package com.rent.movie.dao;

import com.rent.movie.pojo.MovieRentalInfo;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface RentalDao {

    List<Date> getRentalInfoForMovie(String movieId);

    void saveRentalInfo(Date date, String movieId);

    Map<String, List<Date>> getRentalInfo();
}
