package com.rent.movie.pojo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FilmStudio {

    private String id;
    private String studioName;
    private String studioAddress;
}
