package com.rent.movie.service;

import java.util.List;

public interface RentalService {

    String rentMovie(String movieId, String borrowerId);
    List<String> getTopRentedMoviesOfYear(Integer year);
}
