package com.rent.movie.pojo;

import lombok.Builder;
import lombok.Data;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Data
@Builder
public class MovieRentalInfo {
    private Date lastBorrowedDate;
    private Map<Integer,Integer> borrowedYearAndCountMap;
}
