package com.rent.movie.pojo;

import lombok.Builder;
import lombok.Data;

import java.util.Date;
import java.util.Map;

@Data
@Builder
public class Borrower {

    private String id;
    private String firstName;
    private String lastName;
    private String address;
    private Map<String, Date> borrowedMovieIdAndTime;
}
