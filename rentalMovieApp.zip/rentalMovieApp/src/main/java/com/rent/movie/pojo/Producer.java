package com.rent.movie.pojo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Producer {

    private String id;
    private String firstName;
    private String lastName;
}
