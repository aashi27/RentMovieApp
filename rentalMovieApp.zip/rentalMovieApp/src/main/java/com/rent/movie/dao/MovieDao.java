package com.rent.movie.dao;

import com.rent.movie.pojo.Movie;
import org.springframework.stereotype.Repository;


public interface MovieDao {

    String add(Movie movie);

    Movie get(String movieId);


}
