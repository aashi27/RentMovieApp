package com.rent.movie.service.impl;

import com.rent.movie.dao.BorrowerDao;
import com.rent.movie.dao.MovieDao;
import com.rent.movie.dao.RentalDao;
import com.rent.movie.exceptionHandler.CanNotRentMovieException;
import com.rent.movie.pojo.Borrower;
import com.rent.movie.service.RentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.server.ServerRequest;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class RentalServiceImpl implements RentalService {

    @Autowired
    RentalDao rentalDao;

    @Autowired
    MovieDao movieDao;

    @Autowired
    BorrowerDao borrowerDao;

    @Override
    public String rentMovie(String movieId, String borrowerId) {
        Borrower borrower = borrowerDao.get(borrowerId);
        Date date = new Date();

        if(borrower == null) {
            throw new CanNotRentMovieException(CanNotRentMovieException.ErrorCode.BORROWER_NOT_FOUND_PLEASE_REGISTER_THE_BORROWER_FIRST, Map.of("borrowerId", borrowerId),
                    "Borrower is not registered with us, please register first");
        }

        Map<String, Date> borrowedMovieIdAndTime = borrower.getBorrowedMovieIdAndTime();
        if (borrowedMovieIdAndTime.containsKey(movieId)) {
            throw new CanNotRentMovieException(CanNotRentMovieException.ErrorCode.CAN_NOT_RENT_SAME_MOVIE_MORE_THEN_ONCE, Map.of("movieId", movieId),
                    "Movie has already rented by you once");
        }

        long count = borrowedMovieIdAndTime.values().stream().filter(borrowedDate -> borrowedDate.equals(date)).count();
        if (count == 2) {
            throw new CanNotRentMovieException(CanNotRentMovieException.ErrorCode.CAN_NOT_RENT_MORE_THEN_2_MOVIES_AT_A_TIME, Map.of("movieId", movieId),
                    "You have rented 2 movies for today ,please try again tomorrow");
        }

        List<Date> rentalInfoForMovie = rentalDao.getRentalInfoForMovie(movieId);
        if (rentalInfoForMovie.contains(date)) {
            throw new CanNotRentMovieException(CanNotRentMovieException.ErrorCode.MOVIE_IS_RENTED_TO_SOMEONE_ELSE, Map.of("movieId", movieId),
                    "Movie is currently rented by someone else");
        }

        if (movieDao.get(movieId) != null) {
            throw new CanNotRentMovieException(CanNotRentMovieException.ErrorCode.MOVIE_IS_NOT_AVAILABLE, Map.of("movieId", movieId),
                    "We don't have this movie available anymore");
        }

        rentalDao.saveRentalInfo(date, movieId);

        borrowerDao.update(borrowerId, movieId, date);
        return null;
    }


    public List<String> getTopRentedMoviesOfYear(Integer year) {
        if (year == null || year > new Date().getYear()) {
            throw new CanNotRentMovieException(CanNotRentMovieException.ErrorCode.NOT_VALID_YEAR, Map.of("year", year != null ? year : 0),
                    "Year is not valid");
        }
        Map<String, List<Date>> rentalInfo = rentalDao.getRentalInfo();
        Map<String, Long> movieIdAndRentCount = rentalInfo.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().stream().filter(date -> date.getYear() == year).count()));
        List<Map.Entry<String, Long>> results = new ArrayList<>(movieIdAndRentCount.entrySet());
        results.sort((e1, e2) -> (int) (e2.getValue() - e1.getValue()));
        if (results.size() > 10)
            return results.subList(0, 9).stream().map(Map.Entry::getKey).collect(Collectors.toList());
        else {
            return results.stream().map(Map.Entry::getKey).collect(Collectors.toList());
        }

    }
}
