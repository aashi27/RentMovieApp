package com.rent.movie.dao.impl;

import com.rent.movie.dao.BorrowerDao;
import com.rent.movie.pojo.Borrower;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class BorrowerDaoImpl implements BorrowerDao {

    private final Map<String, Borrower> borrowerMap = new ConcurrentHashMap<>();

    @Override
    public void add(Borrower borrower) {

        borrowerMap.put(borrower.getId(), borrower);
    }

    @Override
    public Borrower get(String borrowerId) {
        return borrowerMap.get(borrowerId);
    }

    @Override
    public void update(String borrowerId, String movieId, Date date) {
        borrowerMap.get(borrowerId).getBorrowedMovieIdAndTime().put(movieId, date);
    }
}
